<template>
  <div class="container">
    <div class="title">
      <h1>Guess the number </h1>
    </div>
    <div class="zone">
      <input type="number" name="numberguesser" id="numberguesser" v-model="numberguesser">
      <br>
      <button @click="Guess" id="guess">Guess</button>
      <button @click="Random" id="random">Random</button>
      <h1>{{ Response }}</h1>
    </div>
  </div>
</template>

<script>
export default{
  
  data(){
    return{
      number:0,
      numberguesser:0,
      Response:''
    }
  },
  watch:{
    numberguesser(value){
      if(this.numberguesser < 0 || this.numberguesser > 100){
        this.numberguesser = 0
      }
    }
  },
  methods:{
    Random(){
      this.number = Math.floor(Math.random() * 100) + 1
      this.numberguesser = 0
      this.Response = ''
    },
    Guess(){
      if(this.number === this.numberguesser){
        this.Response = 'Congratulation !You find the number'
      }else if(this.numberguesser > this.number){
        this.Response = 'your number is higher'
      }else if(this.numberguesser < this.number){
        this.Response = 'your number is lower'
      }
    }
  }
}


</script>

